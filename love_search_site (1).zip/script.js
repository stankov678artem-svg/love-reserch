const imageFiles = [
  "IMG_0352.jpg",
  "IMG_0483.jpg",
  "IMG_0553.jpg"
];

function showResults() {
  const loadingMessage = document.getElementById('loadingMessage');
  const resultsDiv = document.getElementById('results');
  resultsDiv.innerHTML = '';
  loadingMessage.style.display = 'block';

  setTimeout(() => {
    loadingMessage.style.display = 'none';

    imageFiles.forEach((filename, index) => {
      const block = document.createElement('div');
      block.className = 'image-block';

      const imageContainer = document.createElement('div');
      imageContainer.className = 'image-placeholder';

      const img = document.createElement('img');
      img.src = filename;
      img.alt = 'Счастье ' + (index + 1);

      imageContainer.appendChild(img);

      const caption = document.createElement('div');
      caption.className = 'caption';
      caption.textContent = 'Мое счастье — это ты, солнце';

      block.appendChild(imageContainer);
      block.appendChild(caption);
      resultsDiv.appendChild(block);
    });
  }, 1500);
}
